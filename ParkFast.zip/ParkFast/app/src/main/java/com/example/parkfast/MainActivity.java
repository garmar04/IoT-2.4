package com.example.parkfast;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    // Este es el método que debe coincidir con el android:onClick
    public void lanzarLogin(View view) {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }
    public void lanzarRegister(View view) {
        // Lógica que quieres que se ejecute cuando se pulse el botón
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }
}